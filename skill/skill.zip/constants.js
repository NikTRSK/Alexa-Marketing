exports.constants = {
	APPNAME: "GUIDE",

	NBC_NETWORK: "NBC",
	ABC_NETWORK: "ABC",
	CBS_NETWORK: "CBS",
	FOX_NETWORK: "FOX",
	CW_NETWORK: "CW",

	LEAD_IN: "LEAD IN",
	LEAD_OUT: "LEAD OUT",

	NEXT: 'next',
	LAST: 'last',

	PAST: -1,
	PRESENT: 0,
    FUTURE: 1,

    WHEN: 'WHEN',
    WHERE: 'WHERE',
    WHEN_WHERE: 'WHEN AND WHERE'
};